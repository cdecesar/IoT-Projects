import os
import time,random,socket,threading

HOST = os.getenv("VIRTUAL_ROOM_SERVER_ADDRESS") #the address used by the server
PORT = int(os.getenv("VIRTUAL_ROOM_SERVER_PORT")) #the port used by the server
sensor = {}

def randomize_sensors():
    global sensor
    sensor = {
        "indoor_light":{
            "active":True if random.randint(0,1) == 1 else False,
            "leave":random.randint(0,100)
        },
        "outside_light":{
            "active":True if random.randint(0,1) == 1 else False,
            "leave":random.randint(0,100)
        },
        "blind": {
            "is_open": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "air_conditioner": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(10,30)
        },
        "presence": {
            "active": True if random.randint(0, 1) == 1 else False,
            "detected":True if random.randint(0, 1) == 1 else False
        },
        "temperature": {
            "active": True if random.randint(0, 1) == 1 else False,
            "temperature": random.randint(0, 40)
        }
    }
    print(sensor)


def get_sensors_state():
    my_bytes = bytearray()
    my_bytes.append(sensor["indoor_light"]["active"])
    my_bytes.append(sensor["indoor_light"]["leave"])
    my_bytes.append(sensor["outside_light"]["active"])
    my_bytes.append(sensor["outside_light"]["leave"])
    my_bytes.append(sensor["blind"]["is_open"])
    my_bytes.append(sensor["blind"]["leave"])
    my_bytes.append(sensor["air_conditioner"]["active"])
    my_bytes.append(sensor["air_conditioner"]["leave"])
    my_bytes.append(sensor["presence"]["active"])
    my_bytes.append(sensor["presence"]["detected"])
    my_bytes.append(sensor["temperature"]["active"])
    my_bytes.append(sensor["temperature"]["temperature"])
    return my_bytes

with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
    print("Conectando con host",HOST, "en el puerto", PORT)
    s.connect((HOST, PORT))
    while True:
        randomize_sensors()
        msg = get_sensors_state()
        print("Enviando",msg)
        s.sendall(msg)
        time.sleep(3)
