import time, os, random, time, subprocess, json
import paho.mqtt.client as mqtt
import Adafruit_DHT

sensor = Adafruit_DHT.DHT11
gpio= 14



def get_host_name():
    bashCommandName = 'echo $HOSTNAME'
    host = subprocess.check_output(['bash', '-c', bashCommandName]).decode("utf-8")[0:-1]
    return host


MQTT_SERVER = "35.204.159.79"
MQTT_SERVER_PORT_CONTROL = 1884
MQTT_SERVER_PORT_TELEMETRIA = 1883
ROOM_ID = get_host_name()
CONFIG_TOPIC = "hotel/rooms/" + ROOM_ID + "/config"
print(CONFIG_TOPIC)
room_number = ""
sensors = {}


def randomize_sensors():
    global sensors
    sensors = {
        "indoor_light": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "outside_light": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "blind": {
            "is_open": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "air_conditioner": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(10, 30)
        },
        "presence": {
            "active": True if random.randint(0, 1) == 1 else False,
            "detected": True if random.randint(0, 1) == 1 else False
        },
        "temperature": {
            "active": True if random.randint(0, 1) == 1 else False,
            "temperature": random.randint(0, 40)
        }
    }


# Conexión inicial. Subscripción al canal de esta habitación y poblicación de nuestro host
def on_connect(client, userdata, flags, rc):
    print("Digital twin connected with code ", rc)
    client.subscribe(CONFIG_TOPIC + "/room")
    print("Subscribed to", CONFIG_TOPIC + "/room")
    client.publish(CONFIG_TOPIC, payload=ROOM_ID, qos=0, retain=True)
    print("Enviando el id", ROOM_ID, "al topic", CONFIG_TOPIC)


# Recepción del número de habitación
def on_message(client, userdata, msg):
    global room_number
    room_number = msg.payload.decode()
    print("Room number received as:", room_number)

def connect_mqtt():
    client.username_pw_set(username="dso_user", password="dso_password")
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_SERVER, MQTT_SERVER_PORT_CONTROL, 60)

def connect_mqtt2():
    client2.username_pw_set(username="dso_user", password="dso_password")
    client2.connect(MQTT_SERVER, MQTT_SERVER_PORT_TELEMETRIA, 60)
    # client.loop_forever()


# Telemetria
client = mqtt.Client()
# Control
client2 = mqtt.Client()
connect_mqtt()
connect_mqtt2()


# Espero a que me indiquen mi numero de habitación
client.loop_start()
while room_number == "":
    time.sleep(1)
client.loop_stop()

TELEMETRY_TOPIC = "hotel/rooms/" + room_number + "/telemetry/"
TEMPERATURE_TOPIC = TELEMETRY_TOPIC + "temperature"
AIR_CONDITIONER_TOPIC = TELEMETRY_TOPIC + "air_conditioner"
BLIND_TOPIC = TELEMETRY_TOPIC + "blind"
# Publico datos aleatorios en un bucle infinito
while True:
    humidity, temperature = Adafruit_DHT.read_retry(sensor, gpio)
    randomize_sensors()
    json_temperature = json.dumps({"temperature": {"active": sensors["temperature"]["active"],
                                                   "value": int(temperature)}})
    json_air = json.dumps({"air_conditioner": {"active": sensors["air_conditioner"]["active"],
                                               "value": sensors["air_conditioner"]["leave"]}})
    json_blind = json.dumps({"blind": {"active": sensors["blind"]["is_open"],
                                       "value": sensors["blind"]["leave"]}})
    #print("Cliente: ", client_telemetria._client_id)
    client2.publish(TEMPERATURE_TOPIC, payload=json_temperature, qos=0, retain=False)
    print("Published", json_temperature, "in", TEMPERATURE_TOPIC)
    client2.publish(AIR_CONDITIONER_TOPIC, payload=json_air, qos=0, retain=False)
    print("Published", json_air, "in", AIR_CONDITIONER_TOPIC)
    client2.publish(BLIND_TOPIC, payload=json_blind, qos=0, retain=False)
    print("Published", json_blind, "in", BLIND_TOPIC)
    time.sleep(random.randint(5, 20))
