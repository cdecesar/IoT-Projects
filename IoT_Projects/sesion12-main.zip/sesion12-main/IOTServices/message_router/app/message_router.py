import json, os, requests, time
import paho.mqtt.client as mqtt

index_room = 1
#MQTT_SERVER = "35.204.159.79"
#MQTT_SERVER_PORT_TELEMETRIA = 1883

MQTT_SERVER = os.getenv("MQTT_SERVER_ADDRESS")
MQTT_SERVER_PORT_TELEMETRIA = int(os.getenv("MQTT_SERVER_PORT_TELEMETRIA"))
MQTT_SERVER_PORT_CONTROL = 1884
API_SERVER_ADDRESS = os.getenv("API_SERVER_ADDRESS")
API_SERVER_PORT = os.getenv("API_SERVER_PORT")
API_URL = "http://" + API_SERVER_ADDRESS + ":" + API_SERVER_PORT
'''
TELEMETRY_TOPIC = "hotel/rooms/+/telemetry/"
TEMPERATURE_TOPIC = TELEMETRY_TOPIC + "temperature"
AIR_CONDITIONER_TOPIC = TELEMETRY_TOPIC + "air_conditioner"
BLIND_TOPIC = TELEMETRY_TOPIC + "blind"
CONFIG_TOPIC = "hotel/rooms/+/config"
ALL_TOPICS = "hotel/rooms/+/telemetry/+"
'''


# Me sescribo a todos los canalas de configuración y de datos
def on_connect(client, userdata, flags, rc):
    print("Connected on subscriber with code ", rc)
    client.subscribe("hotel/rooms/+/telemetry/+")
    print("Subscribed to all telemetry")
    client.subscribe("hotel/rooms/+/config")
    print("Subscribed to all rooms config")


# Procesamiento de cada mensaje que llega
def on_message(client, userdata, msg):
    global index_room
    print("Mensaje recibido en ", msg.topic, " con mensaje", msg.payload.decode())
    topic = (msg.topic).split('/')
    # Una habitación me pide saber su numero (le doy el primero libre)
    if topic[-1] == "config":
        room_name = "Room" + str(index_room)
        print("Digital with id", msg.payload.decode(), "saved as", room_name)
        index_room += 1
        client.publish(msg.topic + "/room", payload=room_name, qos=0, retain=True)
        print("Publicado", room_name, "en TOPIC", msg.topic)
    if "telemetry" in topic:
        payload = json.loads(msg.payload)
        value = -1
        print(payload)
        for i in payload.values():
            value = i["value"]
        requests.post(
            API_URL+"/device_state",
            json={"room": topic[2], "type": topic[-1], "value": value}
        )



client = mqtt.Client()
client.loop_start()
client.username_pw_set(username="dso_user", password="dso_password")
client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_SERVER, MQTT_SERVER_PORT_CONTROL, 60)
client2 = mqtt.Client()
client2.username_pw_set(username="dso_user", password="dso_password")
client2.on_connect = on_connect
client2.on_message = on_message
client2.connect(MQTT_SERVER, MQTT_SERVER_PORT_TELEMETRIA, 60)
client2.loop_forever()
