# %%
import random
from threading import Thread
from multiprocessing import Semaphore
import RPi.GPIO as GPIO
import time
import Adafruit_DHT


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# MOTOR
enable = 21
# Tercero
input_1 = 20
# Cuarto
input_2 = 16
GPIO.setup(enable, GPIO.OUT)
GPIO.setup(input_1, GPIO.OUT)
GPIO.setup(input_2, GPIO.OUT)

color_R = 22
# Tercero
color_G = 17
# Cuarto
color_B = 27
GPIO.setup(color_R, GPIO.OUT)
GPIO.setup(color_G, GPIO.OUT)
GPIO.setup(color_B, GPIO.OUT)

GPIO.setup(enable, GPIO.OUT)
GPIO.setup(input_1, GPIO.OUT)
pwn_input1 = GPIO.PWM(input_1,100)
GPIO.setup(input_2, GPIO.OUT)
pwn_input2 = GPIO.PWM(input_2,100)
pwn_input1.start(0)
pwn_input2.start(0)


global temperatura_global
temperatura_global = 25

semaforo = Semaphore(1)


# SENSOR
sensor = Adafruit_DHT.DHT11
gpio= 14


def motor():
    while True:
        if semaforo.get_value() == 1:
            if temperatura_global == 20:
                GPIO.output(enable,GPIO.HIGH)
                pwn_input1.ChangeDutyCycle(0)
                pwn_input1.ChangeDutyCycle(10)
            elif temperatura_global == 12:
                GPIO.output(enable,GPIO.HIGH)
                pwn_input1.ChangeDutyCycle(0)
                pwn_input1.ChangeDutyCycle(80)
            elif temperatura_global == 30:
                GPIO.output(enable,GPIO.HIGH)
                pwn_input1.ChangeDutyCycle(0)
                pwn_input1.ChangeDutyCycle(60)
            else:
                GPIO.output(enable, GPIO.HIGH)
                pwn_input1.ChangeDutyCycle(0)
                pwn_input1.ChangeDutyCycle(50)

        elif semaforo.get_value() == 0:
            GPIO.output(enable, GPIO.LOW)


def led():
    while True:
        if semaforo.get_value() == 0:
            GPIO.output(color_R, GPIO.LOW)
            GPIO.output(color_G, GPIO.HIGH)
            GPIO.output(color_B, GPIO.LOW)
        else:
            if temperatura_global < 21:
                GPIO.output(color_R, GPIO.HIGH)
                GPIO.output(color_G, GPIO.LOW)
                GPIO.output(color_B, GPIO.LOW)
            elif temperatura_global > 24:
                GPIO.output(color_R, GPIO.LOW)
                GPIO.output(color_G, GPIO.LOW)
                GPIO.output(color_B, GPIO.HIGH)
            else:
                pass


def organizar():

    while True:


        if temperatura_global >= 21 and temperatura_global <=24 and semaforo.get_value() == 1:
            semaforo.acquire()
        elif (temperatura_global < 21 or temperatura_global >24) and semaforo.get_value() == 0:
            semaforo.release()
        else:
            pass

def temperatura():
    humedad = None
    temperatura = None

    while True:
        humidity, temperature = Adafruit_DHT.read_retry(sensor, gpio)

        while humidity is None or temperature is None:
            humidity, temperature = Adafruit_DHT.read_retry(sensor, gpio)

        global temperatura_global
        temperatura_global = temperature
        print(temperatura_global)


        if humedad == None and temperatura == None:
            humedad = humidity
            temperatura = temperature
            print('Temp={0:0.1f}*C  Humidity={1:0.1f}%'.format(temperature, humidity))

        else:
            dif_h = humedad - humidity
            dif_t = temperatura - temperature

            if abs(dif_h) > 0.1 or  abs(dif_t) > 0.1:
                print('Temp={0:0.1f}*C  Humidity={1:0.1f}%'.format(temperature,humidity))
                humedad = humidity
                temperatura = temperature


try:
    hilo_motor = Thread(target=motor)
    hilo_color = Thread(target=organizar)
    hilo_sensor = Thread(target=temperatura)
    hilo_led = Thread(target=led)
    hilo_color.start()
    hilo_motor.start()
    hilo_sensor.start()
    hilo_led.start()
    hilo_motor.join()
    hilo_color.join()
    hilo_sensor.join()
    hilo_led.join()


except:
    GPIO.cleanup()

GPIO.cleanup()
