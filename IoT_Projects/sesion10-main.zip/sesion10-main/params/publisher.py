import time
from random import randint
import paho.mqtt.client
from load_params import getParams
import threading


def send_id(mqtt,id):
    mqtt.publish("devices",payload=id,qos=0,retain=False)
    print("Publicando id ",id)

def send_temperature(mqtt,temp):
    print("Publicada temperatura", temp)
    mqtt.publish("temperature",payload=temp,qos=0,retain=False)

def send_humidity(mqtt,hum):
    mqtt.publish("humidity",payload=hum,qos=0,retain=False)
    print("Publicanda humedad ",hum)

def on_connect(client, userdata, flags,rc):
    if rc==0:
        print("Connected")
    else:
        print("Connect fail, code: ",rc)

def openMqtt(ip,usr,pwd):
    mqtt = paho.mqtt.client.Client()
    mqtt.username_pw_set(username=usr,password=pwd)
    mqtt.on_connect = on_connect
    mqtt.connect(ip,1883,60)
    return mqtt


def publish(mqtt):
    send_id(mqtt,randint(0,1000))
    while True:
        channel = randint(0,1)
        if channel == 0:
            send_temperature(mqtt, randint(-10,35))
        else:
            send_humidity(mqtt,randint(0,100))
        time.sleep((randint(3,10)))

params = getParams()
mqtt = openMqtt(params["mqtt_ip"],params["mqtt_usr"],params["mqtt_pwd"])
publisher_thread = threading.Thread(target=publish,args=(mqtt,))
publisher_thread.start()
mqtt.loop_forever()
