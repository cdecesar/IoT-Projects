import json, os
import paho.mqtt.client as mqtt

index_room = 1
#MQTT_SERVER = "35.204.159.79"
#MQTT_SERVER_PORT_TELEMETRIA = 1883

MQTT_SERVER = os.getenv("MQTT_SERVER_ADDRESS")
MQTT_SERVER_PORT_TELEMETRIA = int(os.getenv("MQTT_SERVER_PORT_TELEMETRIA"))
MQTT_SERVER_PORT_CONTROL = 1884
json_air = []
json_temperature = []
json_blind = []


# Me sescribo a todos los canalas de configuración y de datos
def on_connect(client, userdata, flags, rc):
    print("Connected on subscriber with code ", rc)
    client.subscribe("hotel/rooms/+/telemetry/+")
    print("Subscribed to all telemetry")
    client.subscribe("hotel/rooms/+/config")
    print("Subscribed to all rooms config")


# Procesamiento de cada mensaje que llega
def on_message(client, userdata, msg):
    global index_room, json_temperature, json_air, json_blind
    print("Mensaje recibido en ", msg.topic, " con mensaje", msg.payload.decode())
    topic = (msg.topic).split('/')
    # Una habitación me pide saber su numero (le doy el primero libre)
    if topic[-1] == "config":
        room_name = "Room" + str(index_room)
        print("Digital with id", msg.payload.decode(), "saved as", room_name)
        index_room += 1
        client.publish(msg.topic + "/room", payload=room_name, qos=0, retain=True)
        print("Publicado", room_name, "en TOPIC", msg.topic)
    # En el resto de los casos, proceso el dato y lo escribo en el log
    if topic[-1] == "temperature":
        json_temperature.append(msg.payload.decode())
        with open('temperature.json', 'w') as json_file:
            json.dump(json_temperature, json_file)
    if topic[-1] == "air_conditioner":
        json_air.append(msg.payload.decode())
        with open('air_conditioner.json', 'w') as json_file:
            json.dump(json_air, json_file)
    if topic[-1] == "blind":
        json_blind.append(msg.payload.decode())
        with open('blind.json', 'w') as json_file:
            json.dump(json_blind, json_file)


client = mqtt.Client()
client.loop_start()
client.username_pw_set(username="dso_user", password="dso_password")
client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_SERVER, MQTT_SERVER_PORT_CONTROL, 60)
client2 = mqtt.Client()
client2.username_pw_set(username="dso_user", password="dso_password")
client2.on_connect = on_connect
client2.on_message = on_message
client2.connect(MQTT_SERVER, MQTT_SERVER_PORT_TELEMETRIA, 60)
client2.loop_forever()
