import json, os, requests, time
import threading
import paho.mqtt.client as mqtt
from flask import Flask, request
from flask_cors import CORS

index_room = 1

MQTT_SERVER = os.getenv("MQTT_SERVER_ADDRESS")
MQTT_SERVER_PORT_TELEMETRIA = int(os.getenv("MQTT_SERVER_PORT_TELEMETRIA"))
MQTT_SERVER_PORT_CONTROL = 1884
DATA_INGESTION_API_HOST = os.getenv("DATA_INGESTION_API_HOST")
DATA_INGESTION_API_PORT = os.getenv("DATA_INGESTION_API_PORT")
API_URL = "http://" + DATA_INGESTION_API_HOST + ":" + DATA_INGESTION_API_PORT

TELEMETRY_TOPIC = "hotel/rooms/+/telemetry/"
TEMPERATURE_TOPIC = TELEMETRY_TOPIC + "temperature"
AIR_CONDITIONER_TOPIC = TELEMETRY_TOPIC + "air_conditioner"
BLIND_TOPIC = TELEMETRY_TOPIC + "blind"
CONFIG_TOPIC = "hotel/rooms/+/config"
ALL_TOPICS = "hotel/rooms/+/telemetry/+"


# Me sescribo a todos los canalas de configuración y de datos
def on_connect(client, userdata, flags, rc):
    print("Connected on subscriber with code ", rc)
    client.subscribe("hotel/rooms/+/config")
    print("Subscribed to all rooms config")


def on_connect2(client, userdata, flags, rc):
    print("Connected on subscriber with code ", rc)
    client.subscribe("hotel/rooms/+/telemetry/+")


# Procesamiento de cada mensaje que llega
def on_message(client, userdata, msg):
    global index_room
    print("Mensaje recibido en ", msg.topic, " con mensaje", msg.payload.decode())
    topic = (msg.topic).split('/')
    # Una habitación me pide saber su numero (le doy el primero libre)
    if topic[-1] == "config":
        room_name = "Room" + str(index_room)
        print("Digital with id", msg.payload.decode(), "saved as", room_name)
        index_room += 1
        client.publish(msg.topic + "/room", payload=room_name, qos=0, retain=True)
        print("Publicado", room_name, "en TOPIC", msg.topic)
    if "telemetry" in topic:
        payload = json.loads(msg.payload)
        value = -1
        print(payload)
        for i in payload.keys():
            a = payload.get(i)
            value = a.get('value')
        requests.post(
            API_URL + "/device_state",
            json={"room": topic[2], "type": topic[-1], "value": value}
        )


def send_command(params):
    room = params["room"]
    TELEMETRY_TOPIC = "hotel/rooms/" + room + "/telemetry/"
    topic = TELEMETRY_TOPIC + "/command"
    print(params)
    constante = True
    if constante:
        # client.publish(topic, payload=json.dumps({"mode": value}), qos=0, retain=True)
        client2.publish(topic, payload=json.dumps(params), qos=0, retain=True)
        print("Command message sent throuth " + topic)
        return {"response": "Message successfully sent"}, 200
    else:
        return {"response": "Incorrect type param"}, 401


def send_command2(params):
    print("Parametros", params)
    for item in range(1,41):
        room = "Room"+str(item)
        TELEMETRY_TOPIC = "hotel/rooms/"+room+"/telemetry/"
        topic = TELEMETRY_TOPIC + "/fachada"
        if room in params.get("value"):
            parametros = {"room": room, "type": "outside_light", "value": 100}
        else:
            parametros = {"room": room, "type": "outside_light", "value": 0}
        print("Parametros 2", parametros)
        constante = True
        if constante:
            client2.publish(topic, payload=json.dumps(parametros), qos=0, retain=True)
            print("Command message sent throuth " + topic)
            return {"response": "Message successfully sent"}, 200
        else:
            return {"response": "Incorrect type param"}, 401


app = Flask(__name__)
CORS(app)


@app.route('/device_state', methods=['POST'])
def device_state():
    if request.method == 'POST':
        params = request.get_json()
        return send_command(params)


@app.route('/cambiar_fachada', methods=['POST'])
def cambiar_fachada():
    if request.method == 'POST':
        params = request.get_json()
        return send_command2(params)


def mqtt_listener():
    client2.loop_forever()


client = mqtt.Client()
client.loop_start()
client.username_pw_set(username="dso_user", password="dso_password")
client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_SERVER, MQTT_SERVER_PORT_CONTROL, 60)
# datos
client2 = mqtt.Client()
client2.username_pw_set(username="dso_user", password="dso_password")
client2.on_connect = on_connect2
client2.on_message = on_message
client2.connect(MQTT_SERVER, MQTT_SERVER_PORT_TELEMETRIA, 60)
t1 = threading.Thread(target=mqtt_listener, daemon=True)
t1.start()
API_HOST = os.getenv("API_HOST")
API_PORT = os.getenv("API_PORT")
app.run(host=API_HOST, port=API_PORT, debug=True)


