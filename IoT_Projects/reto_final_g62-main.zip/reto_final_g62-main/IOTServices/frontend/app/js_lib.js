/*
 * Javascript file to implement client side usability for 
 * Operating Systems Desing exercises.
 */
 var api_server_address = "http://35.204.159.79:5001/"

 var get_current_sensor_data = function(){
    $.getJSON( api_server_address+"get_from_data_ingestion", function( data ) {
        console.log("ola")
        $.each(data, function( index, item ) {
          $("#"+item.room).data(item.type, item.value)
            console.log(item.room,item.type,item.value)
      });
    });
}

var draw_rooms = function(){
    $("#rooms").empty()
    var room_index = 1;
    for (var i = 0; i < 8; i++) {
        $("#rooms").append("<tr id='floor"+i+"'></tr>")
        for (var j = 0; j < 5; j++) {
            $("#floor"+i).append("\
                <td \
                data-bs-toggle='modal' \
                data-bs-target='#room_modal' \
                class='room_cell'\
                id='Room"+room_index+"'\
                > \
                Room "+room_index+"\
                </td>"
                )
            room_index++
        }
    }
}


function cambiar_fachada(event){
    event.preventDefault();
    var valor = document.getElementById("rooms_layout").value;
    document.getElementById("rooms_layout").value = '';
    console.log(valor)

    var habitaciones = [];
    if (valor == 'A' || valor == 'E' || valor == 'I' || valor == 'O'|| valor == 'U'){
        for(var i = 1; i<41;i++){
            console.log(i.toString(), typeof i.toString())
            document.getElementById('Room' + i.toString()).style.backgroundColor = '#b6d1ed';
            document.getElementById('Room' + i.toString()).style.color = '#08429899';
        }
        if (valor == 'A'){
            document.getElementById('Room6').style.backgroundColor = 'green';
            document.getElementById('Room7').style.backgroundColor = 'green';
            document.getElementById('Room8').style.backgroundColor = 'green';
            document.getElementById('Room9').style.backgroundColor = 'green';
            document.getElementById('Room10').style.backgroundColor = 'green';
            document.getElementById('Room6').style.color = 'white';
            document.getElementById('Room7').style.color = 'white';
            document.getElementById('Room8').style.color = 'white';
            document.getElementById('Room9').style.color = 'white';
            document.getElementById('Room10').style.color = 'white';

            document.getElementById('Room16').style.backgroundColor = 'green';
            document.getElementById('Room17').style.backgroundColor = 'green';
            document.getElementById('Room18').style.backgroundColor = 'green';
            document.getElementById('Room19').style.backgroundColor = 'green';
            document.getElementById('Room20').style.backgroundColor = 'green';
            document.getElementById('Room16').style.color = 'white';
            document.getElementById('Room17').style.color = 'white';
            document.getElementById('Room18').style.color = 'white';
            document.getElementById('Room19').style.color = 'white';
            document.getElementById('Room20').style.color = 'white';

            document.getElementById('Room26').style.backgroundColor = 'green';
            document.getElementById('Room27').style.backgroundColor = 'green';
            document.getElementById('Room28').style.backgroundColor = 'green';
            document.getElementById('Room29').style.backgroundColor = 'green';
            document.getElementById('Room30').style.backgroundColor = 'green';
            document.getElementById('Room26').style.color = 'white';
            document.getElementById('Room27').style.color = 'white';
            document.getElementById('Room28').style.color = 'white';
            document.getElementById('Room29').style.color = 'white';
            document.getElementById('Room30').style.color = 'white';

            document.getElementById('Room36').style.backgroundColor = 'green';
            document.getElementById('Room37').style.backgroundColor = 'green';
            document.getElementById('Room38').style.backgroundColor = 'green';
            document.getElementById('Room39').style.backgroundColor = 'green';
            document.getElementById('Room40').style.backgroundColor = 'green';
            document.getElementById('Room36').style.color = 'white';
            document.getElementById('Room37').style.color = 'white';
            document.getElementById('Room38').style.color = 'white';
            document.getElementById('Room39').style.color = 'white';
            document.getElementById('Room40').style.color = 'white';

            habitaciones = ["Room6", "Room7", "Room8", "Room9", "Room10", "Room16", "Room17", "Room18", "Room19", 
                "Room20", "Room26", "Room27", "Room28", "Room29", "Room30", "Room36", "Room37", "Room38", "Room39", 'Room40'];
        } 
        if (valor == 'E'){
            document.getElementById('Room1').style.backgroundColor = 'green';
            document.getElementById('Room2').style.backgroundColor = 'green';
            document.getElementById('Room3').style.backgroundColor = 'green';
            document.getElementById('Room4').style.backgroundColor = 'green';
            document.getElementById('Room5').style.backgroundColor = 'green';
            document.getElementById('Room1').style.color = 'white';
            document.getElementById('Room2').style.color = 'white';
            document.getElementById('Room3').style.color = 'white';
            document.getElementById('Room4').style.color = 'white';
            document.getElementById('Room5').style.color = 'white';

            document.getElementById('Room6').style.backgroundColor = 'green';
            document.getElementById('Room11').style.backgroundColor = 'green';
            document.getElementById('Room16').style.backgroundColor = 'green';
            document.getElementById('Room21').style.backgroundColor = 'green';
            document.getElementById('Room26').style.backgroundColor = 'green';
            document.getElementById('Room31').style.backgroundColor = 'green';
            document.getElementById('Room6').style.color = 'white';
            document.getElementById('Room11').style.color = 'white';
            document.getElementById('Room16').style.color = 'white';
            document.getElementById('Room21').style.color = 'white';
            document.getElementById('Room26').style.color = 'white';
            document.getElementById('Room31').style.color = 'white';

            document.getElementById('Room36').style.backgroundColor = 'green';
            document.getElementById('Room37').style.backgroundColor = 'green';
            document.getElementById('Room38').style.backgroundColor = 'green';
            document.getElementById('Room39').style.backgroundColor = 'green';
            document.getElementById('Room40').style.backgroundColor = 'green';
            document.getElementById('Room36').style.color = 'white';
            document.getElementById('Room37').style.color = 'white';
            document.getElementById('Room38').style.color = 'white';
            document.getElementById('Room39').style.color = 'white';
            document.getElementById('Room40').style.color = 'white';

            document.getElementById('Room17').style.backgroundColor = 'green';
            document.getElementById('Room18').style.backgroundColor = 'green';
            document.getElementById('Room21').style.backgroundColor = 'green';
            document.getElementById('Room22').style.backgroundColor = 'green';
            document.getElementById('Room23').style.backgroundColor = 'green';
            document.getElementById('Room17').style.color = 'white';
            document.getElementById('Room18').style.color = 'white';
            document.getElementById('Room21').style.color = 'white';
            document.getElementById('Room22').style.color = 'white';
            document.getElementById('Room23').style.color = 'white';

            habitaciones = ["Room1", "Room2", 'Room3', "Room4", "Room5", "Room6", "Room11", "Room16", "Room21", "Room26", 
                "Room31", "Room16", "Room17", "Room18", "Room21", "Room22", "Room23", "Room36", "Room37", "Room38", "Room39", "Room40"];

        } 
        if (valor == 'I'){
            document.getElementById('Room1').style.backgroundColor = 'green';
            document.getElementById('Room2').style.backgroundColor = 'green';
            document.getElementById('Room3').style.backgroundColor = 'green';
            document.getElementById('Room4').style.backgroundColor = 'green';
            document.getElementById('Room5').style.backgroundColor = 'green';
            document.getElementById('Room1').style.color = 'white';
            document.getElementById('Room2').style.color = 'white';
            document.getElementById('Room3').style.color = 'white';
            document.getElementById('Room4').style.color = 'white';
            document.getElementById('Room5').style.color = 'white';

            document.getElementById('Room36').style.backgroundColor = 'green';
            document.getElementById('Room37').style.backgroundColor = 'green';
            document.getElementById('Room38').style.backgroundColor = 'green';
            document.getElementById('Room39').style.backgroundColor = 'green';
            document.getElementById('Room40').style.backgroundColor = 'green';
            document.getElementById('Room36').style.color = 'white';
            document.getElementById('Room37').style.color = 'white';
            document.getElementById('Room38').style.color = 'white';
            document.getElementById('Room39').style.color = 'white';
            document.getElementById('Room40').style.color = 'white';

            document.getElementById('Room8').style.backgroundColor = 'green';
            document.getElementById('Room13').style.backgroundColor = 'green';
            document.getElementById('Room18').style.backgroundColor = 'green';
            document.getElementById('Room23').style.backgroundColor = 'green';
            document.getElementById('Room28').style.backgroundColor = 'green';
            document.getElementById('Room33').style.backgroundColor = 'green';
            document.getElementById('Room8').style.color = 'white';
            document.getElementById('Room13').style.color = 'white';
            document.getElementById('Room18').style.color = 'white';
            document.getElementById('Room23').style.color = 'white';
            document.getElementById('Room28').style.color = 'white';
            document.getElementById('Room33').style.color = 'white';

            habitaciones = ["Room1", "Room2", "Room3", "Room4", "Room5", "Room36", "Room37", "Room38", "Room39", "Room40",
                "Room8", "Room13", "Room18", "Room23", "Room28", "Room33"];

        } 
        if (valor == 'O'){
            document.getElementById('Room1').style.backgroundColor = 'green';
            document.getElementById('Room2').style.backgroundColor = 'green';
            document.getElementById('Room3').style.backgroundColor = 'green';
            document.getElementById('Room4').style.backgroundColor = 'green';
            document.getElementById('Room5').style.backgroundColor = 'green';
            document.getElementById('Room1').style.color = 'white';
            document.getElementById('Room2').style.color = 'white';
            document.getElementById('Room3').style.color = 'white';
            document.getElementById('Room4').style.color = 'white';
            document.getElementById('Room5').style.color = 'white';

            document.getElementById('Room36').style.backgroundColor = 'green';
            document.getElementById('Room37').style.backgroundColor = 'green';
            document.getElementById('Room38').style.backgroundColor = 'green';
            document.getElementById('Room39').style.backgroundColor = 'green';
            document.getElementById('Room40').style.backgroundColor = 'green';
            document.getElementById('Room36').style.color = 'white';
            document.getElementById('Room37').style.color = 'white';
            document.getElementById('Room38').style.color = 'white';
            document.getElementById('Room39').style.color = 'white';
            document.getElementById('Room40').style.color = 'white';

            document.getElementById('Room6').style.backgroundColor = 'green';
            document.getElementById('Room11').style.backgroundColor = 'green';
            document.getElementById('Room16').style.backgroundColor = 'green';
            document.getElementById('Room21').style.backgroundColor = 'green';
            document.getElementById('Room26').style.backgroundColor = 'green';
            document.getElementById('Room31').style.backgroundColor = 'green';
            document.getElementById('Room6').style.color = 'white';
            document.getElementById('Room11').style.color = 'white';
            document.getElementById('Room16').style.color = 'white';
            document.getElementById('Room21').style.color = 'white';
            document.getElementById('Room26').style.color = 'white';
            document.getElementById('Room31').style.color = 'white';

            document.getElementById('Room10').style.backgroundColor = 'green';
            document.getElementById('Room15').style.backgroundColor = 'green';
            document.getElementById('Room20').style.backgroundColor = 'green';
            document.getElementById('Room25').style.backgroundColor = 'green';
            document.getElementById('Room30').style.backgroundColor = 'green';
            document.getElementById('Room35').style.backgroundColor = 'green';
            document.getElementById('Room10').style.color = 'white';
            document.getElementById('Room15').style.color = 'white';
            document.getElementById('Room20').style.color = 'white';
            document.getElementById('Room25').style.color = 'white';
            document.getElementById('Room30').style.color = 'white';
            document.getElementById('Room35').style.color = 'white';

            habitaciones = ["Room1", "Room2", "Room3", "Room4", "Room5", "Room36", "Room37", "Room38", "Room39", "Room40",
                "Room6", "Room11", "Room16", "Room21", "Room26", "Room31", "Room10", "Room15", "Room20", "Room25", "Room30", "Room35"];
        } 
        if (valor == 'U'){
            document.getElementById('Room1').style.backgroundColor = 'green';
            document.getElementById('Room5').style.backgroundColor = 'green';
            document.getElementById('Room1').style.color = 'white';
            document.getElementById('Room5').style.color = 'white';

            document.getElementById('Room36').style.backgroundColor = 'green';
            document.getElementById('Room37').style.backgroundColor = 'green';
            document.getElementById('Room38').style.backgroundColor = 'green';
            document.getElementById('Room39').style.backgroundColor = 'green';
            document.getElementById('Room40').style.backgroundColor = 'green';
            document.getElementById('Room36').style.color = 'white';
            document.getElementById('Room37').style.color = 'white';
            document.getElementById('Room38').style.color = 'white';
            document.getElementById('Room39').style.color = 'white';
            document.getElementById('Room40').style.color = 'white';

            document.getElementById('Room6').style.backgroundColor = 'green';
            document.getElementById('Room11').style.backgroundColor = 'green';
            document.getElementById('Room16').style.backgroundColor = 'green';
            document.getElementById('Room21').style.backgroundColor = 'green';
            document.getElementById('Room26').style.backgroundColor = 'green';
            document.getElementById('Room31').style.backgroundColor = 'green';
            document.getElementById('Room6').style.color = 'white';
            document.getElementById('Room11').style.color = 'white';
            document.getElementById('Room16').style.color = 'white';
            document.getElementById('Room21').style.color = 'white';
            document.getElementById('Room26').style.color = 'white';
            document.getElementById('Room31').style.color = 'white';

            document.getElementById('Room10').style.backgroundColor = 'green';
            document.getElementById('Room15').style.backgroundColor = 'green';
            document.getElementById('Room20').style.backgroundColor = 'green';
            document.getElementById('Room25').style.backgroundColor = 'green';
            document.getElementById('Room30').style.backgroundColor = 'green';
            document.getElementById('Room35').style.backgroundColor = 'green';
            document.getElementById('Room10').style.color = 'white';
            document.getElementById('Room15').style.color = 'white';
            document.getElementById('Room20').style.color = 'white';
            document.getElementById('Room25').style.color = 'white';
            document.getElementById('Room30').style.color = 'white';
            document.getElementById('Room35').style.color = 'white';

            habitaciones = ["Room1", "Room5", "Room36", "Room37", "Room38", "Room39", "Room40", "Room6", "Room11", "Room16",
                "Room21", "Room26", "Room31", "Room10", "Room15", "Room20", "Room25", "Room30", "Room35"];
        }
        $.ajax({
            type: "POST",
            url: api_server_address+"cambiar_fachada",
            data: JSON.stringify({
                "type":"cambio_fachada",
                "value":habitaciones,
            }),
            contentType: 'application/json'
        });
    } else {
       //alert('Esa configuracion no existe')
    }
}

$("#air_conditioner_mode").change(function(){
    var value = $(this).val()
    $.ajax({
        type: "POST",
        url: api_server_address+"device_state",
        data: JSON.stringify({
            "room":$("#room_id").text(),
            "type":"air_conditioner",
            "value":value,
        }),
        contentType: 'application/json'
    });
})
$("#interior_light_mode").change(function(){
    var value = $(this).val()
    $.ajax({
        type: "POST",
        url: api_server_address+"device_state",
        data: JSON.stringify({
            "room":$("#room_id").text(),
            "type":"interior_light",
            "value":value,
        }),
        contentType: 'application/json'
    });
})

$("#outside_light_mode").change(function(){
    var value = $(this).val()
    $.ajax({
        type: "POST",
        url: api_server_address+"device_state",
        data: JSON.stringify({
            "room":$("#room_id").text(),
            "type":"outside_light",
            "value":value,
        }),
        contentType: 'application/json'
    });
})

$("#blind_mode").change(function(){
    var value = $(this).val()
    $.ajax({
        type: "POST",
        url: api_server_address+"device_state",
        data: JSON.stringify({
            "room":$("#room_id").text(),
            "type":"blind",
            "value":value,
        }),
        contentType: 'application/json'
    });
})


$("#rooms").on("click", "td", function() {
    var habitacion = $(this).attr("id");
    $.get(api_server_address+"device_state", function( data ) {
        var datos = JSON.parse(data);
        var temp = 'nada';
        var presencia = 'nada';
        var luz_i = 'nada';
        var luz_e = 'nada';
        var aire = 'nada';
        var persiana = 'nada';
        for(var i = 0; i < datos.room.length; i++) {
            if (datos.room[i] == habitacion) {
                var tipo = datos.type[i];
                
                if (tipo == 'temperature' && temp == 'nada') {
                    console.log(tipo)
                    temp = datos.value[i];
                }
                if (tipo == 'presence' && presencia == 'nada') {
                    if (datos.value[i] == '0'){
                        presencia = 'Presente';
                    } else {
                        presencia = 'No presente';
                    }
                }
                if (tipo == 'outside_light' && luz_e == 'nada') {
                    luz_e = datos.value[i];
                }
                if (tipo == 'inside_light' && luz_i == 'nada') {
                    luz_i = datos.value[i];
                }
                if (tipo == 'air_conditioner' && aire == 'nada') {
                    aire = datos.value[i];
                }
                if (tipo == 'blind' && persiana == 'nada') {
                    persiana = datos.value[i];
                }
            }
        }
        $("#room_id").text($( this ).attr("id") || habitacion);
        $("#temperature_value").text($( this ).data("temperature") || temp);
        $("#interior_light_value").text($( this ).data("inside_light") || luz_i);
        $("#outside_light_value").text($( this ).data("outside_light") || luz_e);
        $("#presence_value").text($( this ).data("presence") || presencia);
        $("#air_conditioner_value").text($( this ).data("air-level") || aire);
        $("#blind_value").text($( this ).data("blind") || persiana);
    })
});

document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('boton_cambiar_fachada').addEventListener('click', cambiar_fachada);
});


draw_rooms()
//setInterval(get_current_sensor_data,2000)
