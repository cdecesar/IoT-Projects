# Access MySQL CLI
# docker ps
# docker exec -it iotservices_mariaDB_1 mysql -u dso_db_user -pdso_db_root_password
# docker exec -it iotservices_mariaDB_1 mysql -u root -pdso_db_root_password
# mysql -u dso_db_user -pdso_db_password

# create database
create database dso_db;

# drop database
drop database dso_db;


# Create a new user (only with local access) and grant privileges to this user on the
grant all privileges on dso_db.* TO 'dso_db_user'@'%' identified by 'dso_db_password';

#After modifying the MarianDB grant tables, execute the following command inorder to
flush privileges;

#Change to the created databases
use dso_db;

#create table for sensor data
CREATE TABLE device_state(
    id MEDIUMINT NOT NULL AUTO_INCREMENT,
    room varchar(20) NOT NULL,
    type varchar(30) NOT NULL,
    value TINYINT NOT NULL,
    date DATETIME NOT NULL,
    PRIMARY KEY (id)
);
#query over table sensor_data
SELECT * FROM device_state ORDER BY date DESC LIMIT 100;