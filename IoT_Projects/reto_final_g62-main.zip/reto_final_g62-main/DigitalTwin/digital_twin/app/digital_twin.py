import threading
import time, os, random, time, subprocess, json
import paho.mqtt.client as mqtt


def get_host_name():
    bashCommandName = 'echo $HOSTNAME'
    host = subprocess.check_output(['bash', '-c', bashCommandName]).decode("utf-8")[0:-1]
    return host


MQTT_SERVER = os.getenv("MQTT_SERVER_ADDRESS")
MQTT_SERVER_PORT_CONTROL = int(os.getenv("MQTT_SERVER_PORT_CONTROL"))
MQTT_SERVER_PORT_TELEMETRIA = int(os.getenv("MQTT_SERVER_PORT_TELEMETRIA"))
ROOM_ID = get_host_name()
CONFIG_TOPIC = "hotel/rooms/" + ROOM_ID + "/config"
print(CONFIG_TOPIC)

sensors = {}

global room_number
room_number = ""
global temperatura
temperatura = 0
global aire_acondicionado
aire_acondicionado = 0
global persiana
persiana = 0
global luz_interior
luz_interior = 0
global luz_exterior
luz_exterior = 0
global presencia
presencia = 0

def randomize_sensors():
    global sensors
    sensors = {
        "interior_light": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "outside_light": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "blind": {
            "is_open": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 100)
        },
        "air_conditioner": {
            "active": True if random.randint(0, 1) == 1 else False,
            "leave": random.randint(0, 30)
        },
        "presence": {
            "active": True if random.randint(0, 1) == 1 else False,
            "detected": True if random.randint(0, 1) == 1 else False
        },
        "temperature": {
            "active": True if random.randint(0, 1) == 1 else False,
            "temperature": random.randint(0, 40)
        }
    }


# Conexión inicial. Subscripción al canal de esta habitación y poblicación de nuestro host
def on_connect(client, userdata, flags, rc):
    print("Digital twin connected with code ", rc)
    client.subscribe(CONFIG_TOPIC + "/room")
    print("Subscribed to", CONFIG_TOPIC + "/room")
    client.publish(CONFIG_TOPIC, payload=ROOM_ID, qos=0, retain=True)
    print("Enviando el id", ROOM_ID, "al topic", CONFIG_TOPIC)


# Recepción del número de habitación
def on_message(client, userdata, msg):
    global room_number
    room_number = msg.payload.decode()
    print("Room number received as:", room_number)

def connect_mqtt():
    client.username_pw_set(username="dso_user", password="dso_password")
    client.on_connect = on_connect
    client.on_message = on_message
    client.will_set(CONFIG_TOPIC, payload="Offline",qos=0, retain=True)
    client.connect(MQTT_SERVER, MQTT_SERVER_PORT_CONTROL, 60)

def on_connect2(client, userdata, flags, rc):
    client2.subscribe(TEMPERATURE_TOPIC)
    client2.subscribe(AIR_CONDITIONER_TOPIC)
    client2.subscribe(BLIND_TOPIC)
    client2.subscribe(INTERIOR_LIGHT_TOPIC)
    client2.subscribe(OUTSIDE_LIGHT_TOPIC)
    client2.subscribe(TOPIC_RASPI)
    client2.subscribe(TOPIC_COMMAND)
    client2.subscribe(TEMPERATURE_TOPIC_RASPI)
    client2.subscribe(TOPIC_FACHADA)
    client2.subscribe(TOPIC_DISCONNECT_RASPI)



def on_message2(client, userdata, msg):
    global temperatura, aire_acondicionado, persiana
    topic =(msg.topic).split('/')
    print("Topic: ", topic)
    # cambios que nos router
    if topic[-1] == 'command':
        parametros = msg.payload.decode()
        parametros = json.loads(parametros)
        tipo = parametros.get("type")
        temperature = random.randint(0, 40)
        json_temperature = json.dumps({"temperature": {"active": sensors["temperature"]["active"],
                                                   "value":  temperature}})
        client2.publish(TEMPERATURE_TOPIC, payload=json_temperature, qos=0, retain=False)
        if tipo == "air_conditioner":
            aire_acondicionado = parametros.get("value")
            json_air = json.dumps({"air_conditioner": {"active": sensors["air_conditioner"]["active"],
                                                       "value": aire_acondicionado}})
            print(json_air)
            client2.publish(AIR_CONDITIONER_TOPIC, payload=json_air, qos=0, retain=False)
        elif tipo == "outside_light":

            json_outside_light = json.dumps({"outside_light": {"active": sensors["outside_light"]["active"],
                                                       "value": parametros.get("value")}})
            print(json_outside_light)
            client2.publish(OUTSIDE_LIGHT_TOPIC, payload=json_outside_light, qos=0, retain=False)
        elif tipo == "interior_light":
            json_interior_light = json.dumps({"interior_light": {"active": sensors["interior_light"]["active"],
                                                       "value": parametros.get("value")}})
            print(json_interior_light)
            client2.publish(INTERIOR_LIGHT_TOPIC, payload=json_interior_light, qos=0, retain=False)
            if str(parametros.get("value")) == "100" or str(parametros.get("value")) == "50":
                json_presence = json.dumps({"presence": {"active": sensors["presence"]["active"],
                                                                 "value": 1}})

                client2.publish(PRESENCE_TOPIC, payload=json_presence, qos=0, retain=False)
            else:
                json_presence = json.dumps({"presence": {"active": sensors["presence"]["active"],
                                                             "value": 0}})
                client2.publish(PRESENCE_TOPIC, payload=json_presence, qos=0, retain=False)
        elif tipo == "blind":
            json_blind = json.dumps({"blind": {"is_open": sensors["blind"]["leave"],
                                                       "value": parametros.get("value")}})
            client2.publish(BLIND_TOPIC, payload=json_blind, qos=0, retain=False)
        print(parametros)
        client2.publish(TOPIC_RASPI, payload=str(parametros), qos=0, retain=False)
    if topic[-1] == 'temperature_raspi':
        temperature = msg.payload.decode()
        print("Temperatura",temperature)
        client2.publish(TEMPERATURE_TOPIC, payload=temperature, qos=0, retain=False)
    if topic[-1] == 'fachada':
        global room_number, luz_interior
        datos_habitaciones = msg.payload.decode()
        datos_habitaciones = json.loads(datos_habitaciones)
        if room_number == datos_habitaciones.get("room"):
            json_outside_light = json.dumps({"outside_light": {"active": sensors["outside_light"]["active"],
                                                       "value": datos_habitaciones.get("value")}})
            print(json_outside_light)
            parametros = {"room": room_number, "type": "outside_light", "value": datos_habitaciones.get("value")}
            client2.publish(OUTSIDE_LIGHT_TOPIC, payload=json_outside_light, qos=0, retain=False)
            client2.publish(TOPIC_RASPI, payload=json.dumps(parametros), qos=0, retain=False)

        else:
            json_outside_light = json.dumps({"outside_light": {"active": sensors["outside_light"]["active"],
                                                               "value": "0"}})
            luz_interior = 0
            print(json_outside_light)
            parametros = {"room": room_number, "type": "outside_light", "value": 0}
            client2.publish(OUTSIDE_LIGHT_TOPIC, payload=json_outside_light, qos=0, retain=False)
            client2.publish(TOPIC_RASPI, payload=json.dumps(parametros), qos=0, retain=False)


def mqtt_listener():
    client2.loop_forever()

def connect_mqtt2():
    client2.username_pw_set(username="dso_user", password="dso_password")
    client2.on_connect = on_connect2
    client2.on_message = on_message2
    client2.will_set(TEMPERATURE_TOPIC, payload="Offline",qos=0, retain=True)
    client2.will_set(TOPIC_COMMAND, payload="Offline",qos=0, retain=True)
    client2.connect(MQTT_SERVER, MQTT_SERVER_PORT_TELEMETRIA, 60)
    t1 = threading.Thread(target=mqtt_listener, daemon=True)
    t1.start()
    # client.loop_forever()


# Control
client = mqtt.Client()
# Telemetria
client2 = mqtt.Client()
connect_mqtt()

# Espero a que me indiquen mi numero de habitación
client.loop_start()
while room_number == "":
    time.sleep(1)
client.loop_stop()

#router
TELEMETRY_TOPIC = "hotel/rooms/" + room_number + "/telemetry/"
TEMPERATURE_TOPIC = TELEMETRY_TOPIC + "temperature"
AIR_CONDITIONER_TOPIC = TELEMETRY_TOPIC + "air_conditioner"
BLIND_TOPIC = TELEMETRY_TOPIC + "blind"
OUTSIDE_LIGHT_TOPIC = TELEMETRY_TOPIC + "outside_light"
INTERIOR_LIGHT_TOPIC = TELEMETRY_TOPIC + "inside_light"
PRESENCE_TOPIC = TELEMETRY_TOPIC + "presence"


#recibir raspi
TEMPERATURE_TOPIC_RASPI = "hotel/rooms/" + room_number + "/temperatura_raspi/"


#mandar raspi
TOPIC_COMMAND = TELEMETRY_TOPIC + "/command"
TOPIC_RASPI = TELEMETRY_TOPIC + "/raspi"
TOPIC_FACHADA = TELEMETRY_TOPIC + "/fachada"
TOPIC_DISCONNECT_RASPI = TELEMETRY_TOPIC + "disconnect_raspi"
TOPIC_DISCONNECT = TELEMETRY_TOPIC + "disconnect"



connect_mqtt2()
# Publico datos aleatorios en un bucle infini
contador = 0
while True:
    if contador == 0:
        randomize_sensors()
        json_temperature = json.dumps({"temperature": {"active": sensors["temperature"]["active"],
                                                       "value": sensors["temperature"]["temperature"]}})
        json_air = json.dumps({"air_conditioner": {"active": sensors["air_conditioner"]["active"],
                                                   "value": sensors["air_conditioner"]["leave"]}})
        json_blind = json.dumps({"blind": {"active": sensors["blind"]["is_open"],
                                           "value": sensors["blind"]["leave"]}})
        json_outside_light = json.dumps({"outside_light": {"active": sensors["outside_light"]["active"],
                                                           "value": sensors["outside_light"]["leave"]}})
        json_interior_light = json.dumps({"interior_light": {"active": sensors["interior_light"]["active"],
                                                           "value": sensors["interior_light"]["leave"]}})
        json_presence = json.dumps({"presence": {"active": sensors["presence"]["active"],
                                                           "value": sensors["presence"]["detected"]}})
        client2.publish(OUTSIDE_LIGHT_TOPIC, payload=json_outside_light, qos=0, retain=False)
        client2.publish(INTERIOR_LIGHT_TOPIC, payload=json_interior_light, qos=0, retain=False)
        client2.publish(PRESENCE_TOPIC, payload=json_presence, qos=0, retain=False)
        client2.publish(TEMPERATURE_TOPIC, payload=json_temperature, qos=0, retain=False)
        client2.publish(AIR_CONDITIONER_TOPIC, payload=json_air, qos=0, retain=False)
        client2.publish(BLIND_TOPIC, payload=json_blind, qos=0, retain=False)
        contador += 1
    else:time.sleep(5)