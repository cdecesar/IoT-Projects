import ast
import threading
import time, os, random, time, subprocess, json
import paho.mqtt.client as mqtt
import Adafruit_DHT
import RPi.GPIO as GPIO

sensor = Adafruit_DHT.DHT11
gpio = 14
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)



# MOTOR
enable = 21
# Tercero
input_1 = 20
# Cuarto
input_2 = 16
GPIO.setup(enable, GPIO.OUT)
GPIO.setup(input_1, GPIO.OUT)
pwn_input1 = GPIO.PWM(input_1,100)
GPIO.setup(input_2, GPIO.OUT)
pwn_input2 = GPIO.PWM(input_2,100)
pwn_input1.start(0)
pwn_input2.start(0)


GPIO.setup(18, GPIO.OUT)
pwn = GPIO.PWM(18,100)
pwn.start(0)

GPIO.setup(23, GPIO.OUT)
pwn_2 = GPIO.PWM(23,100)
pwn_2.start(0)


color_R = 22
# Tercero
color_G = 17
# Cuarto
color_B = 27
GPIO.setup(color_R, GPIO.OUT)
GPIO.setup(color_G, GPIO.OUT)
GPIO.setup(color_B, GPIO.OUT)




def get_host_name():
    bashCommandName = 'echo $HOSTNAME'
    host = subprocess.check_output(['bash', '-c', bashCommandName]).decode("utf-8")[0:-1]
    return host


MQTT_SERVER = "35.204.159.79"
MQTT_SERVER_PORT = 1884
MQTT_SERVER_PORT_TELEMETRIA = 1883
ROOM_ID = get_host_name()
CONFIG_TOPIC = "hotel/rooms/" + ROOM_ID + "/config"
global room_number
room_number = ""
sensors = {}

global temperature
temperature = 0
global aire_acondicionado
aire_acondicionado = 0
global persiana
persiana = 0


# Conexión inicial. Subscripción al canal de esta habitación y poblicación de nuestro host



def temperatura():
    humidity, temperature = Adafruit_DHT.read_retry(sensor, gpio)
    json_temperature = json.dumps({"temperature": {"active": True,
                                                   "value": temperature}})
    client2.publish(TEMPERATURE_TOPIC_RASPI, payload=json_temperature, qos=0, retain=False)

def blind(parametros):
    valor = parametros.get("value")
    # open
    if str(valor) == "100":
        GPIO.output(enable, GPIO.HIGH)
        pwn_input1.ChangeDutyCycle(0)
        pwn_input2.ChangeDutyCycle(100)
        grados = random.randint(91, 180)
        json_blind = json.dumps({"blind": {"active": 1,
                                                 "value": grados}})
        print(json_blind)
    # close
    elif str(valor) == "0":
        GPIO.output(enable, GPIO.LOW)
        grados = 0
        json_blind = json.dumps({"blind": {"active": 0,
                                                 "value": grados}})
        print(json_blind)

    # half
    elif str(valor) == "50":
        GPIO.output(enable, GPIO.HIGH)
        pwn_input1.ChangeDutyCycle(0)
        pwn_input2.ChangeDutyCycle(50)
        grados = random.randint(1, 90)
        json_blind = json.dumps({"blind": {"active": 1,
                                                 "value": grados}})
        print(json_blind)



def exterior_light(parametros):
    valor = parametros.get("value")
    #bright
    if str(valor) == "100":
        intensidad = 100
        pwn.ChangeDutyCycle(intensidad)
        json_exterior_light = json.dumps({"outside_light": {"active": True,
                                                       "value": intensidad}})
        print(json_exterior_light)
    # half
    if str(valor) == "50":
        intensidad = 50
        pwn.ChangeDutyCycle(intensidad)
        json_exterior_light = json.dumps({"outside_light": {"active": True,
                                                             "value": intensidad}})
        print(json_exterior_light)
    # dark
    if str(valor) == "0":
        intensidad = 0
        pwn.ChangeDutyCycle(intensidad)
        json_exterior_light = json.dumps({"outside_light": {"active": True,
                                                             "value": intensidad}})
        print(json_exterior_light)
def interior_light(parametros):
    valor = parametros.get("value")
    # bright
    if str(valor) == "100":
        intensidad = 100
        pwn_2.ChangeDutyCycle(intensidad)
        json_interior_light = json.dumps({"interior_light": {"active": True,
                                                       "value": intensidad}})
        print(json_interior_light)

    # half
    if str(valor) == "50":
        intensidad = 50
        pwn_2.ChangeDutyCycle(intensidad)
        json_interior_light = json.dumps({"interior_light": {"active": True,
                                                       "value": intensidad}})
        print(json_interior_light)

    # dark
    if str(valor) == "0":
        intensidad = 0
        pwn_2.ChangeDutyCycle(intensidad)
        json_interior_light = json.dumps({"interior_light": {"active": True,
                                                       "value": intensidad}})
        print(json_interior_light)


def air_conditioner(parametros):
    valor = parametros.get("value")
    #cold -> verde
    if str(valor) == "0":
        GPIO.output(color_R, GPIO.HIGH)
        GPIO.output(color_G, GPIO.HIGH)
        GPIO.output(color_B, GPIO.HIGH)
        air_conditioner = 0
        json_air_conditioner = json.dumps({"air_conditioner": {"active": 1,
                                                       "value": air_conditioner}})
        print(json_air_conditioner)

    # warm -> rojo
    if str(valor) == "1":
        GPIO.output(color_R, GPIO.HIGH)
        GPIO.output(color_G, GPIO.LOW)
        GPIO.output(color_B, GPIO.LOW)
        air_conditioner = 1
        json_air_conditioner = json.dumps({"air_conditioner": {"active": 1,
                                                       "value": air_conditioner}})
        print(json_air_conditioner)

    # off -> nada
    if str(valor) == "2":
        GPIO.output(color_R, GPIO.LOW)
        GPIO.output(color_G, GPIO.LOW)
        GPIO.output(color_B, GPIO.LOW)
        air_conditioner = 2
        json_air_conditioner = json.dumps({"air_conditioner": {"active": 1,
                                                       "value": air_conditioner}})
        print(json_air_conditioner)






def on_connect2(client, userdata, flags, rc):
    client2.subscribe(TOPIC_RASPI)

def on_message2(client, userdata, msg):
    global temperature, aire_acondicionado, persiana
    topic =(msg.topic).split('/')
    if topic[-1] == "raspi":
        parametros = msg.payload.decode()
        parametros = ast.literal_eval(parametros)
        print(parametros)
        hilo_temperatura = threading.Thread(target=temperature)
        hilo_temperatura.start()
        hilo_temperatura.join()
        if parametros.get("type") == "blind":
            hilo_blind = threading.Thread(target=blind, args=(parametros,))
            hilo_blind.start()
            hilo_blind.join()
        elif parametros.get("type") == "outside_light":
            hilo_exterior_light = threading.Thread(target=exterior_light, args=(parametros,))
            hilo_exterior_light.start()
            hilo_exterior_light.join()
        elif parametros.get("type") == "interior_light":
            hilo_interior_light = threading.Thread(target=interior_light, args=(parametros,))
            hilo_interior_light.start()
            hilo_interior_light.join()
        elif parametros.get("type") == "air_conditioner":
            hilo_air_conditioner = threading.Thread(target=air_conditioner, args=(parametros,))
            hilo_air_conditioner.start()
            hilo_air_conditioner.join()



room_number = "Room1"
TELEMETRY_TOPIC = "hotel/rooms/" + room_number + "/telemetry/"


TEMPERATURE_TOPIC_RASPI = "hotel/rooms/" + room_number + "/temperatura_raspi/"



TOPIC_RASPI = TELEMETRY_TOPIC + "/raspi"

client2 = mqtt.Client()
client2.username_pw_set(username="dso_user", password="dso_password")
client2.on_connect = on_connect2
client2.on_message = on_message2
client2.will_set(TOPIC_RASPI, payload="Offline", qos=0, retain=True)
client2.will_set(TEMPERATURE_TOPIC_RASPI, payload="Offline",qos=0, retain=True)
client2.connect(MQTT_SERVER, MQTT_SERVER_PORT_TELEMETRIA, 60)
client2.loop_forever()

