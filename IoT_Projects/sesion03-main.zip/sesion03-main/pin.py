import subprocess
'''ping'''
host = "mytravelyourtravel.com"
otp = subprocess.check_output(["ping",host,"-c5"])

print(otp)