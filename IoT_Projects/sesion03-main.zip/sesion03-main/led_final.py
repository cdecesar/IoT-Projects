import RPi.GPIO as GPIO
import time
'''ejercicio final'''
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(18, GPIO.OUT)
pwn = GPIO.PWM(18,100)
pwn.start(0)

for item in range(2):

    for intensidad in range(0, 101, 10):
        print(intensidad)
        pwn.ChangeDutyCycle(intensidad)
        time.sleep(1)

    for i in range(5):
        print("ON: ", i + 1)
        pwn.ChangeDutyCycle(100)
        time.sleep(1)
        print("OFF: ", i + 1)
        pwn.ChangeDutyCycle(0)
        time.sleep(1)

    for intensidad in range(100, -1, -10):
        pwn.ChangeDutyCycle(intensidad)
        time.sleep(1)
        print(intensidad)

    for i in range(5):
        print("ON: ", i + 1)
        pwn.ChangeDutyCycle(100)
        time.sleep(1)
        print("OFF: ", i + 1)
        pwn.ChangeDutyCycle(0)
        time.sleep(1)



GPIO.cleanup()