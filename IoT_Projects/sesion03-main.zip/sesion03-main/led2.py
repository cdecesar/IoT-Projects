import RPi.GPIO as GPIO
import time
'''ejercicio 2'''
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(18, GPIO.OUT)
pwn = GPIO.PWM(18,100)
pwn.start(0)

for i in range(10):
    for intensidad in range(0,101,20):
        print(intensidad)
        pwn.ChangeDutyCycle(intensidad)
        time.sleep(0.5)


GPIO.cleanup()