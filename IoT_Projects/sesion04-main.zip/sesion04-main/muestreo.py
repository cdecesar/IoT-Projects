import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

GPIO.setwarnings(False)
IN = 16
OUT = 20

GPIO.setup(OUT, GPIO.OUT)
GPIO.setup(IN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

i = 1

try:
    while i<20:
        if GPIO.input(IN) == GPIO.LOW:  #esta pulsado
            print('Pulsado |', i)
            GPIO.output(OUT, GPIO.HIGH)
            #GPIO.output(20, GPIO.HIGH)
        else:                           #no esta pulsado
            print('No Pulsado |', i)
            GPIO.output(OUT, GPIO.LOW)
            #GPIO.output(20, GPIO.LOW)
        time.sleep(0.5)
        i += 1
finally:
    GPIO.cleanup()