import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

GPIO.setwarnings(False)
IN = 16
OUT = 20

GPIO.setup(OUT, GPIO.OUT)
GPIO.setup(IN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

i = 1

try:
    while i < 10:
        GPIO.wait_for_edge(IN, GPIO.FALLING)
        if GPIO.input(IN) == GPIO.LOW:
            print('ON')
            GPIO.output(OUT, GPIO.HIGH)
        else:
            print('OFF')
            GPIO.output(OUT, GPIO.LOW)
        i += 1
finally:
    GPIO.cleanup()


def theend(sig, frame):
    print('')