import RPi.GPIO as GPIO
import sys
import time
import signal

def theend(sig, frame):
    print("Limpiando todo para salir...")
    GPIO.cleanup()
    sys.exit()


def click(channel):

    if GPIO.input(IN) == GPIO.LOW:
        print('ON')
        pwn.ChangeDutyCycle(100)
        time.sleep(1)


    else:
        print('OFF')
        pwn.ChangeDutyCycle(0)
        time.sleep(1)


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
IN = 16
OUT = 20
GPIO.setup(IN,GPIO.IN,pull_up_down = GPIO.PUD_UP )
GPIO.setup(OUT,GPIO.OUT)
pwn = GPIO.PWM(OUT,100)
pwn.start(0)
GPIO.add_event_detect(IN, GPIO.BOTH, callback=click, bouncetime=100)    # no bloque el codigo, solo añade un evento. Ejecuta la funcion cuando pasa algo
                                                                        # bouncetime evita que en esos milisegundos no se llame otra vez a la funcion.
                                                                        # Asi si dejamos de pulsar sin querer un momento, no se ejecuta si volvemos a pulsar al instante
signal.signal(signal.SIGINT, theend)
signal.pause()                                                          # Detiene la ejecucion pero no finaliza el programa?? Ayuda a trabajar con hilos