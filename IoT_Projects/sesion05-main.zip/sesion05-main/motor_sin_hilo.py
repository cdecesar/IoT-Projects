#%%
import threading
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


#%%
# Empezando por la izquierda
# Primero
color_R = 22
# Tercero
color_G = 27
# Cuarto
color_B = 17
GPIO.setup(color_R, GPIO.OUT)
GPIO.setup(color_G, GPIO.OUT)
GPIO.setup(color_B, GPIO.OUT)







for i in range(2):
    print("Iteracion ", i)
    GPIO.output(color_R, GPIO.HIGH)
    GPIO.output(color_G, GPIO.LOW)
    GPIO.output(color_B, GPIO.LOW)

    time.sleep(1)
    GPIO.output(color_R, GPIO.LOW)
    GPIO.output(color_G, GPIO.LOW)
    GPIO.output(color_B, GPIO.LOW)
    time.sleep(1)

GPIO.cleanup()






