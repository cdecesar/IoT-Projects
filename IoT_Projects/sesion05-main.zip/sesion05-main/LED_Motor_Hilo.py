# %%
import random
from threading import Thread
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

color_R = 22
# Tercero
color_G = 27
# Cuarto
color_B = 17
GPIO.setup(color_R, GPIO.OUT)
GPIO.setup(color_G, GPIO.OUT)
GPIO.setup(color_B, GPIO.OUT)

enable = 21
# Tercero
input_1 = 20
# Cuarto
input_2 = 16
GPIO.setup(enable, GPIO.OUT)
GPIO.setup(input_1, GPIO.OUT)
GPIO.setup(input_2, GPIO.OUT)

color_del_led = None

def motor():
    for i in range(3):
        time.sleep(1)
        print("Iteracion ", i)
        GPIO.output(enable, GPIO.HIGH)
        GPIO.output(input_1, GPIO.LOW)
        GPIO.output(input_2, GPIO.HIGH)

        time.sleep(3)
        GPIO.output(enable, GPIO.LOW)
        GPIO.output(input_1, GPIO.HIGH)
        GPIO.output(input_2, GPIO.LOW)
        time.sleep(3)

def funcionar():
    ultimo_color = None
    for i in range(10):
        a = random.choice([0, 1, 2, 3, 4, 5])
        if ultimo_color == None or ultimo_color == 0:
            if a == 0 :
                GPIO.output(color_R, GPIO.HIGH)
                GPIO.output(color_G, GPIO.LOW)
                GPIO.output(color_B, GPIO.LOW)
                ultimo_color = a
            else:

                GPIO.output(color_R, random.choice([GPIO.LOW, GPIO.HIGH]))
                GPIO.output(color_G, random.choice([GPIO.LOW, GPIO.HIGH]))
                GPIO.output(color_B, random.choice([GPIO.LOW, GPIO.HIGH]))
                ultimo_color = a
        else:
            GPIO.output(color_R, GPIO.HIGH)
            GPIO.output(color_G, GPIO.LOW)
            GPIO.output(color_B, GPIO.LOW)
            ultimo_color = 0

        time.sleep(3)
        GPIO.output(color_R, GPIO.LOW)
        GPIO.output(color_G, GPIO.LOW)
        GPIO.output(color_B, GPIO.LOW)
        time.sleep(0.5)

    GPIO.cleanup()
    print('ola')


try:
    hilo_motor = Thread(target=motor)
    hilo_led = Thread(target=funcionar)
    hilo_motor.start()
    hilo_led.start()
    hilo_led.join()
    hilo_motor.join()
except:
    GPIO.cleanup()
