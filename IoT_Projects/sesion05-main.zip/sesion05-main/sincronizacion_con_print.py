# %%
import random
from threading import Thread
from multiprocessing import Semaphore
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

color_R = 22
# Tercero
color_G = 27
# Cuarto
color_B = 17
GPIO.setup(color_R, GPIO.OUT)
GPIO.setup(color_G, GPIO.OUT)
GPIO.setup(color_B, GPIO.OUT)

enable = 21
# Tercero
input_1 = 20
# Cuarto
input_2 = 16
GPIO.setup(enable, GPIO.OUT)
GPIO.setup(input_1, GPIO.OUT)
pwn_input1 = GPIO.PWM(input_1,100)
GPIO.setup(input_2, GPIO.OUT)
pwn_input2 = GPIO.PWM(input_2,100)
pwn_input1.start(0)
pwn_input2.start(0)
global color_del_led
color_del_led = 0
semaforo = Semaphore(1)

global velocidad
velocidad = 0

global color_led_imprimir
color_led_imprimir = 0

colores_print = {0: "rojo",1:"amarillo",2:"blanco",3:"apagado",4:"morado",5:"azul turquesa"}
velocidades_motor = {0: 0,1:20,2:40,3:60,4:80,5:100}

def motor():
    while color_del_led != 6:

        if semaforo.get_value() == 1:

            direccion = random.choice([1,2])
            if direccion == 1:
                    GPIO.output(enable, GPIO.HIGH)
                    pwn_input1.ChangeDutyCycle(0)
                    pwn_input2.ChangeDutyCycle(velocidades_motor.get(color_del_led))
                    time.sleep(3)

            elif direccion == 2:
                GPIO.output(enable, GPIO.HIGH)
                pwn_input2.ChangeDutyCycle(0)
                pwn_input1.ChangeDutyCycle(velocidades_motor.get(color_del_led))
                time.sleep(3)

        elif semaforo.get_value() == 0:
            GPIO.output(enable, GPIO.HIGH)
            pwn_input1.ChangeDutyCycle(0)
            pwn_input1.ChangeDutyCycle(0)
            time.sleep(3)




def funcionar():
    colores = {0: [GPIO.HIGH, GPIO.LOW, GPIO.LOW], 1: [GPIO.HIGH, GPIO.HIGH, GPIO.LOW],
               2: [GPIO.HIGH, GPIO.HIGH, GPIO.HIGH],
               3: [GPIO.LOW, GPIO.LOW, GPIO.LOW], 4: [GPIO.HIGH, GPIO.LOW, GPIO.HIGH],
               5: [GPIO.LOW, GPIO.HIGH, GPIO.HIGH]}



    while color_del_led != 6:
        GPIO.output(color_R, colores[color_del_led][0])
        GPIO.output(color_G, colores[color_del_led][1])
        GPIO.output(color_B, colores[color_del_led][2])
        global color_led_imprimir
        color_led_imprimir = colores[color_del_led]
        if color_del_led == 0 and semaforo.get_value() == 1:
            semaforo.acquire()
        elif color_del_led != 0 and semaforo.get_value() == 0:
            semaforo.release()
        else:
            pass


def organizar():

    for i in range(10):
        a = random.choice([0,1,2,3,4,5])
        global color_del_led
        color_del_led = a
        print("Color del led: ",colores_print.get(a))
        print("Velocidad del motor: ", velocidades_motor.get(a))

        time.sleep(3)

    color_del_led = 6



try:
    hilo_motor = Thread(target=motor)
    hilo_led = Thread(target=funcionar)
    hilo_color = Thread(target=organizar)
    hilo_color.start()
    hilo_motor.start()
    hilo_led.start()
    hilo_led.join()
    hilo_motor.join()
    hilo_color.join()

except:
    GPIO.cleanup()

GPIO.cleanup()
