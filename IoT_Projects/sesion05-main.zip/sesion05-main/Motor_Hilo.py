#%%
import threading
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)


enable = 21
# Tercero
input_1 = 20
# Cuarto
input_2 = 16
GPIO.setup(enable, GPIO.OUT)
GPIO.setup(input_1, GPIO.OUT)
GPIO.setup(input_2, GPIO.OUT)

def funcionar():

    GPIO.output(enable, GPIO.HIGH)
    GPIO.output(input_1, GPIO.LOW)
    GPIO.output(input_2, GPIO.HIGH)

    time.sleep(5)
    GPIO.output(enable, GPIO.LOW)
    GPIO.output(input_1, GPIO.HIGH)
    GPIO.output(input_2, GPIO.LOW)
    time.sleep(5)
    GPIO.cleanup()

try:
    hilo_motor = threading.Thread(target=funcionar)
    hilo_motor.start()
    hilo_motor.join()
except:
    GPIO.cleanup()
